** HealBot Continued **

Latest Download from Curse: http://wow.curse.com/downloads/wow-addons/details/heal-bot-continued.aspx



=================================
--- Installation and Updating ---
=================================

Installing and Updating
-----------------------

1: Completely log off WoW
2: Copy the folders into your WoW Addons folder.
3: Logon to WoW on your main Healer.
4: As a priority you should open the options and configure spells, cures and buffs.


Updating Troubles
-----------------

***** If you get nil errors after updating *****

1: Completely log off WoW
2: Run the Reset_HealBot.bat file in the Healbot addon folder, this clears old saved Healbot settings from your WTF folder.
3: Logon to WoW on your main Healer.
4: As a priority you should open the options and configure spells, cures and buffs.



===================
--- The Folders ---
===================

Copy the folders into you Addons directory
------------------------------------------

Healbot                     = This is the main addon
TitanHealBot                = This is a plugin for the Titan bar addon, TitanHealBot is an optional plugin for people who use Titan.



=========================
--- Additional Addons ---
=========================

Recommended Additions
---------------------

SharedMedia                 = This addon is designed to be used by addons, it gives additional textures, fonts and sounds. This addon is recommended.
                              http://wow.curse.com/downloads/wow-addons/details/sharedmedia.aspx

SharedMediaAdditionalFonts  = This addon can be used with SharedMedia to gives additional fonts. This addon is recommended.
                              http://wow.curse.com/downloads/wow-addons/details/shared-media-additional-fonts.aspx

TipTac                      = Improve the look of your tooltips
                              http://wow.curse.com/downloads/wow-addons/details/tip-tac.aspx


Recommended Plugins
-------------------

Broker_Healbot              = This is a broker for Healbot, that works with compatible addons such as ChocolateBar.
                              http://wow.curse.com/downloads/wow-addons/details/broker_healbot.aspx

Fubar_HBskinFU              = This is a FuBar specific plugin.
                              http://wow.curse.com/downloads/wow-addons/details/fubar_hbskinfu.aspx


