QuestHelper_File["bst_libaboutpanel.lua"] = "4.0.6.161r"
QuestHelper_Loadtime["bst_libaboutpanel.lua"] = GetTime()
