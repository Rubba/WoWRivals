QuestHelper_File["bst_range.lua"] = "4.0.6.161r"
QuestHelper_Loadtime["bst_range.lua"] = GetTime()
