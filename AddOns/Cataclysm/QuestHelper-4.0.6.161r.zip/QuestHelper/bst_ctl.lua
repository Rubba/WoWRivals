QuestHelper_File["bst_ctl.lua"] = "4.0.6.161r"
QuestHelper_Loadtime["bst_ctl.lua"] = GetTime()
